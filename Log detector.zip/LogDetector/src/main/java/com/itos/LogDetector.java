package com.itos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Marius
 */

public class LogDetector {

	// Main is the Main Source for the program.
	public static void main(String[] args) {
		if(args.length == 0) {
		 System.err.println("No file given");
		 return;
		}
		//The String filename is the argument for the programs main part.
		String fileName = args[0];
		try {
			File file = new File(fileName); // Read file
					//"C:\\Users\\dfkis\\OneDrive\\Skrivebord\\Log4J-example-with-java-master\\src\\main\\java\\com\\itos\\factory\\FactoryWork.java"); // file location
			FileReader fr = new FileReader(file); // reads the file
			BufferedReader br = new BufferedReader(fr); // creates a buffering character input stream
			String line; 
			int lineNumber = 1;  // This is the counter for the Analysere.
			while ((line = br.readLine()) != null) {
				System.out.println("line " + lineNumber + " Ok = " + loglineOk(line) + ", '" + line + "'");
				lineNumber++;
			}
			fr.close(); // closes the stream and release the resources
			System.out.println("DONE with " + lineNumber + " lines"); //The result of all the lines from the program. 
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	// This method returns true if the logline is god and false if the logline is weak (The Argument "ll" is logline)
	
	public static boolean loglineOk(String ll) {  // Info
		if (ll.isEmpty()) {
			return true;
		}

		if ((ll.indexOf(".info(") < 0) && (ll.indexOf(".warn(") < 0) && (ll.indexOf(".error(") < 0)  // Infomation 
				
				&& (ll.indexOf(".fatal(") < 0) && (ll.indexOf(".debug(") < 0)) {
			return true;
		}
		// The result from the detector
		int firstQuotePos = ll.indexOf("\"");

		int secondQuotePos = ll.indexOf("\"", firstQuotePos + 1);

		if(secondQuotePos != -1) {
			return true;
		}
		if(ll.length() <= (secondQuotePos + 2 )) {
			return true;
		}
		// The calculation for the Analysere 
		String testChar = ll.substring(secondQuotePos + 1, secondQuotePos + 2);
		if (",".equals(testChar)) {
			return true;
		} else {
			if (ll.indexOf(")", secondQuotePos + 1) == -1) {
				return true;
			}
			if (ll.indexOf("+", secondQuotePos + 1) == -1) {
				return false;
			} else {
				return true;
			}
		}
	}

}