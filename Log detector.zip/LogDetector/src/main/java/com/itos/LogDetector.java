package com.itos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * 
 * @author Marius
 *
 */
public class LogDetector {


	public static void main(String[] args) {
		if(args.length == 0) {
		 System.err.println("No file given");
		 return;
		}
		String fileName = args[0];
		try {
			File file = new File(fileName);
					//"C:\\Users\\dfkis\\OneDrive\\Skrivebord\\Log4J-example-with-java-master\\src\\main\\java\\com\\itos\\factory\\FactoryWork.java"); // file location
			FileReader fr = new FileReader(file); // reads the file
			BufferedReader br = new BufferedReader(fr); // creates a buffering character input stream
			String line; 
			int lineNumber = 1;
			while ((line = br.readLine()) != null) {
				System.out.println("line " + lineNumber + " Ok = " + loglineOk(line) + ", '" + line + "'");
				lineNumber++;
			}
			fr.close(); // closes the stream and release the resources
			System.out.println("DONE with " + lineNumber + " lines"); //The result of all the lines from the program. 
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static boolean loglineOk(String ll) {
		if (ll.isEmpty()) {
			return true;
		}

		if ((ll.indexOf(".info(") < 0) && (ll.indexOf(".warn(") < 0) && (ll.indexOf(".error(") < 0)  //
				
				&& (ll.indexOf(".fatal(") < 0) && (ll.indexOf(".debug(") < 0)) {
			return true;
		}
		// The result from the detector
		int firstQuotePos = ll.indexOf("\"");
		// System.out.println(firstQuotePos);

		int secondQuotePos = ll.indexOf("\"", firstQuotePos + 1);
		// System.out.println(secondQuotePos);

		String testChar = ll.substring(secondQuotePos + 1, secondQuotePos + 2);
		// System.out.println(testChar);
		if (",".equals(testChar)) {
			// System.out.println("godline");
			return true;
		} else {
			if (ll.indexOf(")", secondQuotePos + 1) == -1) {
				return true;
			}
			if (ll.indexOf("+", secondQuotePos + 1) == -1) {
				// System.out.println("badline");
				return false;
			} else {
				// System.out.println("godline");
				return true;
			}
		}
	}

}